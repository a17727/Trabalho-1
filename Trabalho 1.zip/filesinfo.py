import time
import json
import os



'''


'''

class FileInfo:
    def __init__(self):
        self.id = None
        self.name = None
        self.dateTime = None
        self.ok_tests = None
        self.nok_tests = None
        self.ok_subtests = None
        self.nok_subtests = None

    def UpdateFileInfo(self, filesNo, filePath, okTests, notOkTests, okSubtests, notOkSubtests):
        
        self.id = filesNo
        self.name = os.path.basename(filePath)
        self.dateTime = time.asctime()
        self.ok_tests = okTests
        self.nok_tests = notOkTests
        self.ok_subtests = okSubtests
        self.nok_subtests = notOkSubtests

    def SaveToFile(self, filePath):
        jsonified_object = self.__dict__
        with open(filePath, 'a+') as output:
            json.dump(jsonified_object, output)